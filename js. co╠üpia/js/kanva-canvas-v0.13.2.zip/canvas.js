// Kanva v0.13.2-pro — canvas.js (texto/contorno estáveis + wrap livre + clamps de viewport)
// Atualizado: 2025-11-03
// ----------------------------------------------------------
// Destaques:
//  - Escalonamento PROPORCIONAL estável (4 cantos): size e width escalam juntos (centro fixo).
//  - Contorno em "em": largura do contorno = (outline.em * fontSize) → sem sombra grossa ou tremedeira.
//  - Wrap lateral direito (handle E) LIVRE: você pode estender a caixa; o texto reflowa sem travar antes.
//  - Anti-jitter: não recalcula proporções a cada frame; usa snapshot do início do drag.
//  - Guarda de viewport: evita que a caixa saia totalmente da tela durante move/scale/rotate.
//  - Multitoque somente para CANVAS (pan/zoom/rotação globais) + duplo toque alterna Fit/100%.
//
// Observação importante sobre contorno:
//  - Objetos novos usam outline.em = 0.06 (≈6% do fontSize).
//  - Se um objeto antigo tiver outline.width absoluto, fazemos migração automática para "em".
// ----------------------------------------------------------

function initCanvas() {
  // ---------- Boot ----------
  const canvas = document.getElementById('kanva');
  const ctx = canvas.getContext('2d', { alpha: false });
  const DPR = Math.max(1, Math.min(3, window.devicePixelRatio || 1));

  // Projeto (tamanho do “papel”)
  const defW = parseInt(getQueryParam?.('w','1080') ?? '1080', 10) || 1080;
  const defH = parseInt(getQueryParam?.('h','1080') ?? '1080', 10) || 1080;
  const project = { width: defW, height: defH };

  // Transformações globais do CANVAS
  let scale = 1, rotation = 0, translateX = 0, translateY = -20;

  // HUD
  const zoomDisplay = document.getElementById('zoomDisplay');
  const rotationDisplay = document.getElementById('rotationDisplay');

  // Objetos e seleção
  const objects = [];
  let activeObjId = null;

  // ---------- Consts de interação ----------
  const SELECT_TOL_SCR = 16;     // tolerância p/ acertar seleção (px de tela)
  const HANDLE_R_SCR   = 9;      // raio visual dos handles (px de tela)
  const ROT_RING_IN    = 22;     // anel de rotação (interno) px de tela
  const ROT_RING_OUT   = 40;     // anel de rotação (externo) px de tela (estilo Picsart)
  const MARGIN_SCR     = 6;      // margem interna do contorno (px de tela, constante)
  const ROT_SMOOTH     = 0.15;   // suavização da rotação local (sensação fluida)
  const VIEWPAD_SCR    = 24;     // folga mínima do box em relação às bordas da viewport (px de tela)
  const MAX_FONT_SIZE  = 1024;   // teto seguro p/ size (anti “explosão”)
  const MIN_FONT_SIZE  = 6;      // piso p/ size
  const EPS            = 0.0001; // epsilon p/ evitar divisão por zero
  const MAX_WRAP_W     = 8192;   // largura máxima da caixa de texto

  // Estado de drag para objetos
  let drag = null;
  let mouseDownPos = null;

  // Multitoque (apenas 2 dedos para o CANVAS)
  let pinchLastDist = 0, pinchLastAngle = 0, pinchLastCenter = null;

  // Toque de 1 dedo para editar OBJETO
  let activeTouchId = null;
  let touchEditingActive = false;

  // Posições dos handles em tela, atualizadas durante o desenho
  const overlayHit = {
    TL:null, TR:null, BR:null, BL:null, // cantos (escala)
    E:null, // wrap (meio direita)
    ROTC:null, // { top, knob } do anel
    boxPath:null // quadrilátero da caixa de seleção (para “move”)
  };

  // ---------- Utils: Canvas e coordenadas ----------
  function setCanvasSize() {
    const w = window.innerWidth, h = window.innerHeight;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    canvas.width = Math.floor(w * DPR);
    canvas.height = Math.floor(h * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }
  function screenSize() { return { w: canvas.width / DPR, h: canvas.height / DPR }; }

  function worldToScreen(wx, wy) {
    const { w:SW, h:SH } = screenSize();
    const cos = Math.cos(rotation), sin = Math.sin(rotation);
    const rx = wx * cos - wy * sin;
    const ry = wx * sin + wy * cos;
    return { x: SW/2 + translateX + rx * scale, y: SH/2 + translateY + ry * scale };
  }

  function screenToWorld(sx, sy) {
    const { w:SW, h:SH } = screenSize();
    const dx = sx - (SW/2 + translateX);
    const dy = sy - (SH/2 + translateY);
    const inv = 1 / scale;
    const cos = Math.cos(-rotation), sin = Math.sin(-rotation);
    return {
      x: (dx*inv)*cos - (dy*inv)*sin,
      y: (dx*inv)*sin + (dy*inv)*cos
    };
  }

  function screenDeltaToWorld(dx, dy) {
    const inv = 1 / scale;
    const cos = Math.cos(-rotation), sin = Math.sin(-rotation);
    return {
      x: (dx*inv)*cos - (dy*inv)*sin,
      y: (dx*inv)*sin + (dy*inv)*cos
    };
  }

  function rotateAround(px, py, cx, cy, ang){
    const dx = px - cx, dy = py - cy;
    const cos = Math.cos(ang), sin = Math.sin(ang);
    return { x: cx + dx*cos - dy*sin, y: cy + dx*sin + dy*cos };
  }

  // ---------- Layout de texto (wrap por caractere) ----------
  function layoutTextCharWrap(obj){
    const text = String(obj.text || '');
    const maxW = Math.max(20, Math.min(MAX_WRAP_W, obj.width || 400));
    const chars = [...text];
    const lines = [];
    let line = '';

    ctx.save();
    ctx.font = `${obj.size}px sans-serif`;

    for (let i=0;i<chars.length;i++){
      const test = line + chars[i];
      const w = ctx.measureText(test).width;
      if (w <= maxW || line === '') {
        line = test;
      } else {
        lines.push(line);
        line = chars[i];
      }
    }
    if (line) lines.push(line);

    const lineHeight = obj.size * 1.2;
    const height = Math.max(lineHeight, lines.length * lineHeight);

    let widest = 0;
    for (const l of lines) widest = Math.max(widest, ctx.measureText(l).width);
    const width = Math.max(maxW, widest);

    ctx.restore();
    return { lines, width, height, lineHeight };
  }

  // Margem interna/raio dos handles em “world” (constantes em tela)
  function worldMargin(){ return MARGIN_SCR / scale; }
  function handleRWorld(){ return HANDLE_R_SCR / scale; }

  // ---------- Helpers: contorno em em ----------
  function migrateOutlineToEm(o){
    if (!o.outline) return;
    if (typeof o.outline.em === 'number') return; // já em em
    const baseSize = Math.max(1, o.size || 48);
    const abs = Math.max(0, o.outline.width || 0);
    const em = abs ? (abs / baseSize) : 0.06; // default 6%
    o.outline = { color: o.outline.color || '#000', em };
  }
  function outlineWidth(o){
    if (!o.outline) return 0;
    migrateOutlineToEm(o);
    return (o.outline.em || 0) * (o.size || 0);
  }

  // ---------- Aux: caixa do objeto em tela ----------
  function getActiveBoxScreen(o){
    if (!o) return null;
    const lay = layoutTextCharWrap(o);
    const m = worldMargin();
    const halfW = (o.width || lay.width)/2 + m;
    const halfH =  lay.height/2 + m;

    const TL = {x:-halfW, y:-halfH}, TR = {x: halfW, y:-halfH};
    const BR = {x: halfW, y: halfH}, BL = {x:-halfW, y: halfH};

    const toWorld = (p)=> rotateAround(p.x, p.y, 0, 0, o.rotationLocal || 0);
    const addObj  = (p)=> ({ x: p.x + o.x, y: p.y + o.y });

    const TLw = addObj(toWorld(TL)), TRw = addObj(toWorld(TR));
    const BRw = addObj(toWorld(BR)), BLw = addObj(toWorld(BL));

    return {
      quadScr: [TLw,TRw,BRw,BLw].map(p=>worldToScreen(p.x,p.y)),
      centerScr: worldToScreen(o.x, o.y)
    };
  }

  // Garante que o box fique dentro da viewport com uma folga fixa (px de tela)
  function clampActiveInsideViewport(o){
    const info = getActiveBoxScreen(o);
    if (!info) return;
    const { w:SW, h:SH } = screenSize();
    const pad = VIEWPAD_SCR;

    const xs = info.quadScr.map(p=>p.x), ys = info.quadScr.map(p=>p.y);
    let minX = Math.min(...xs), maxX = Math.max(...xs);
    let minY = Math.min(...ys), maxY = Math.max(...ys);

    let shiftX = 0, shiftY = 0;
    if (minX < pad) shiftX = pad - minX;
    if (maxX > SW - pad) shiftX = Math.min(shiftX, (SW - pad) - maxX);
    if (minY < pad) shiftY = pad - minY;
    if (maxY > SH - pad) shiftY = Math.min(shiftY, (SH - pad) - maxY);

    if (shiftX !== 0 || shiftY !== 0){
      const d = screenDeltaToWorld(shiftX, shiftY);
      o.x += d.x;
      o.y += d.y;
    }
  }

  // ---------- Desenho ----------
  function drawChecker(size, c1, c2, width, height){
    const cols = Math.ceil(width / size), rows = Math.ceil(height / size);
    for (let y=0;y<rows;y++)
      for (let x=0;x<cols;x++){
        ctx.fillStyle = ((x+y)%2===0)?c1:c2;
        ctx.fillRect(x*size - width/2, y*size - height/2, size, size);
      }
  }

  function draw(){
    const { w:SW, h:SH } = screenSize();

    // Reset
    ctx.setTransform(1,0,0,1,0,0);
    ctx.clearRect(0,0,canvas.width,canvas.height);

    // Transform global
    ctx.setTransform(DPR,0,0,DPR,0,0);
    ctx.translate(SW/2 + translateX, SH/2 + translateY);
    ctx.rotate(rotation);
    ctx.scale(scale, scale);

    // Fundo do projeto (shadow limitado ao fundo, sem "vazar")
    const PW = project.width, PH = project.height;
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.6)";
    ctx.shadowBlur = 20;
    ctx.shadowOffsetY = 8;
    ctx.fillStyle = "#111827";
    ctx.fillRect(-PW/2, -PH/2, PW, PH);
    ctx.restore();

    drawChecker(40, "#f5f5f5", "#d1d1d1", PW, PH);

    // Moldura e guias
    ctx.strokeStyle = "#999";
    ctx.lineWidth = 2/scale;
    ctx.strokeRect(-PW/2, -PH/2, PW, PH);

    ctx.strokeStyle = "#888";
    ctx.beginPath();
    ctx.moveTo(-PW/2, 0); ctx.lineTo(PW/2, 0);
    ctx.moveTo(0, -PH/2); ctx.lineTo(0, PH/2);
    ctx.stroke();

    // Objetos
    for (const o of objects){
      if (o.type !== 'Texto') continue;
      migrateOutlineToEm(o);
      const lay = layoutTextCharWrap(o);

      ctx.save();
      ctx.translate(o.x, o.y);
      const ang = o.rotationLocal || 0;
      if (ang) ctx.rotate(ang);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = `${o.size}px sans-serif`;

      // Outline (sem shadow extra; largura baseada em em)
      const ow = outlineWidth(o);
      if (ow > 0){
        ctx.lineWidth = ow;
        ctx.strokeStyle = o.outline.color || '#000';
        for (let i=0;i<lay.lines.length;i++){
          const y = (i - (lay.lines.length-1)/2) * lay.lineHeight;
          ctx.strokeText(lay.lines[i], 0, y);
        }
      }

      // Fill
      ctx.fillStyle = o.color || '#fff';
      for (let i=0;i<lay.lines.length;i++){
        const y = (i - (lay.lines.length-1)/2) * lay.lineHeight;
        ctx.fillText(lay.lines[i], 0, y);
      }

      // Seleção ativa
      if (o.id === activeObjId) drawSelection(o, lay);
      ctx.restore();
    }

    // HUD
    if (zoomDisplay) zoomDisplay.textContent = `Zoom: ${(scale*100).toFixed(0)}%`;
    if (rotationDisplay){
      const deg = (rotation*180/Math.PI) % 360;
      rotationDisplay.textContent = `Rot: ${(deg<0?deg+360:deg).toFixed(0)}°`;
    }
  }

  // Desenha seleção + pontos + prepara overlayHit
  function drawSelection(o, lay){
    const m = worldMargin();
    const halfW = (o.width || lay.width)/2 + m;
    const halfH = lay.height/2 + m;

    const TL = {x:-halfW, y:-halfH};
    const TR = {x: halfW, y:-halfH};
    const BR = {x: halfW, y: halfH};
    const BL = {x:-halfW, y: halfH};

    // caixa tracejada
    ctx.save();
    ctx.strokeStyle = "#60a5fa";
    ctx.lineWidth = 2/scale;
    ctx.setLineDash([8,6]);
    ctx.beginPath();
    ctx.moveTo(TL.x, TL.y);
    ctx.lineTo(TR.x, TR.y);
    ctx.lineTo(BR.x, BR.y);
    ctx.lineTo(BL.x, BL.y);
    ctx.closePath();
    ctx.stroke();
    ctx.setLineDash([]);

    // 4 cantos
    const r = handleRWorld();
    fillHandle(TL.x, TL.y, r);
    fillHandle(TR.x, TR.y, r);
    fillHandle(BR.x, BR.y, r);
    fillHandle(BL.x, BL.y, r);

    // wrap (meio da direita)
    const E = { x:(TR.x+BR.x)/2, y:(TR.y+BR.y)/2 };
    fillHandle(E.x, E.y, r);

    // anel/knob de rotação
    const offset = 48/scale;
    const topC   = { x:0, y:-halfH };
    const rotC   = { x:0, y:-halfH - offset };

    ctx.beginPath();
    ctx.arc(topC.x, topC.y, offset, -Math.PI, 0, false);
    ctx.strokeStyle = "#60a5fa";
    ctx.lineWidth = 2/scale;
    ctx.stroke();

    fillHandle(rotC.x, rotC.y, r*1.05);
    ctx.restore();

    // Atualiza pontos em TELA (hit-test)
    const toWorld = (p)=> rotateAround(p.x, p.y, 0, 0, o.rotationLocal || 0);
    const addObj  = (p)=> ({ x: p.x + o.x, y: p.y + o.y });

    const TLw = addObj(toWorld(TL));
    const TRw = addObj(toWorld(TR));
    const BRw = addObj(toWorld(BR));
    const BLw = addObj(toWorld(BL));
    const Ew  = addObj(toWorld(E));
    const topCw = addObj(toWorld(topC));
    const rotCw = addObj(toWorld(rotC));

    overlayHit.TL = worldToScreen(TLw.x, TLw.y);
    overlayHit.TR = worldToScreen(TRw.x, TRw.y);
    overlayHit.BR = worldToScreen(BRw.x, BRw.y);
    overlayHit.BL = worldToScreen(BLw.x, BLw.y);
    overlayHit.E  = worldToScreen(Ew.x, Ew.y);
    overlayHit.ROTC = { top: worldToScreen(topCw.x, topCw.y), knob: worldToScreen(rotCw.x, rotCw.y) };
    overlayHit.boxPath = [TLw,TRw,BRw,BLw].map(p=>worldToScreen(p.x, p.y));
  }

  function fillHandle(x, y, rWorld){
    ctx.save();
    ctx.fillStyle = "#111827";
    ctx.strokeStyle = "#60a5fa";
    ctx.lineWidth = 2/scale;
    ctx.beginPath();
    ctx.arc(x, y, rWorld, 0, Math.PI*2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  // ---------- Hit-tests ----------
  function near(p1, p2, tol){ return Math.hypot(p1.x-p2.x, p1.y-p2.y) <= tol; }
  function pointInQuad(px, py, quad){
    function area(a,b,c){ return Math.abs((a.x*(b.y-c.y)+b.x*(c.y-a.y)+c.x*(a.y-b.y))/2); }
    const P={x:px,y:py}, A=quad[0],B=quad[1],C=quad[2],D=quad[3];
    const box = area(A,B,C)+area(A,C,D);
    const sum = area(P,A,B)+area(P,B,C)+area(P,C,D)+area(P,D,A);
    return Math.abs(sum - box) < 0.9;
  }

  function hitHandles(clientX, clientY){
    if (!activeObjId) return { mode:'none' };
    const tol = HANDLE_R_SCR + 4;

    if (overlayHit.TL && near({x:clientX,y:clientY}, overlayHit.TL, tol)) return { mode:'scale', corner:'nw' };
    if (overlayHit.TR && near({x:clientX,y:clientY}, overlayHit.TR, tol)) return { mode:'scale', corner:'ne' };
    if (overlayHit.BR && near({x:clientX,y:clientY}, overlayHit.BR, tol)) return { mode:'scale', corner:'se' };
    if (overlayHit.BL && near({x:clientX,y:clientY}, overlayHit.BL, tol)) return { mode:'scale', corner:'sw' };

    if (overlayHit.E  && near({x:clientX,y:clientY}, overlayHit.E,  tol)) return { mode:'wrap-e' };

    if (overlayHit.ROTC){
      const tc = overlayHit.ROTC.top;
      const d = Math.hypot(clientX - tc.x, clientY - tc.y);
      if (d >= ROT_RING_IN && d <= ROT_RING_OUT) return { mode:'rotate' };
      const knob = overlayHit.ROTC.knob;
      if (near({x:clientX,y:clientY}, knob, tol)) return { mode:'rotate' };
    }

    if (overlayHit.boxPath && pointInQuad(clientX, clientY, overlayHit.boxPath)) return { mode:'move' };

    return { mode:'none' };
  }

  function hitSelect(worldX, worldY){
    let found = null;
    for (const o of objects){
      if (o.type !== 'Texto') continue;

      const lay = layoutTextCharWrap(o);
      const m = worldMargin();
      const halfW = (o.width || lay.width)/2 + m;
      const halfH = lay.height/2 + m;

      const ang = -(o.rotationLocal || 0);
      const cos = Math.cos(ang), sin = Math.sin(ang);
      const lx = (worldX - o.x)*cos - (worldY - o.y)*sin;
      const ly = (worldX - o.x)*sin + (worldY - o.y)*cos;

      const tol = SELECT_TOL_SCR / scale;
      if (lx > -halfW - tol && lx < halfW + tol && ly > -halfH - tol && ly < halfH + tol) { found = o; break; }
    }
    return found;
  }

  // ---------- Mouse (objetos) ----------
  canvas.addEventListener('mousedown', (e)=>{
    mouseDownPos = { x:e.clientX, y:e.clientY };

    // 1) tenta handles/anel
    const hit = hitHandles(e.clientX, e.clientY);
    if (hit.mode !== 'none') { beginDrag(e, hit); return; }

    // 2) Seleção direta no corpo do objeto
    const rect = canvas.getBoundingClientRect();
    const wpos = screenToWorld(e.clientX - rect.left, e.clientY - rect.top);
    const found = hitSelect(wpos.x, wpos.y);
    if (found){
      activeObjId = found.id;
      window.dispatchEvent(new CustomEvent('kanva:select', { detail:{ type:found.type, id:found.id } }));
      draw();
      beginDrag(e, { mode:'move' });
    } else {
      if (activeObjId){
        activeObjId = null;
        window.dispatchEvent(new Event('kanva:deselect'));
        draw();
      }
    }
  });

  canvas.addEventListener('click', (e)=>{
    if (!mouseDownPos) return;
    const moved = Math.hypot(e.clientX - mouseDownPos.x, e.clientY - mouseDownPos.y);
    mouseDownPos = null;
    if (moved > 3) return;
  });

  // ---------- Drag de OBJETO ----------
  function beginDrag(e, hit){
    const obj = objects.find(o=>o.id===activeObjId);
    drag = {
      mode: hit.mode,
      corner: hit.corner || null,
      start: { x:e.clientX, y:e.clientY },
      moved: false,
      objStart: obj ? { 
        x:obj.x, y:obj.y, 
        size:obj.size, 
        width:Math.min(MAX_WRAP_W, obj.width||400), 
        rot:obj.rotationLocal||0,
        outlineEm: (obj.outline && typeof obj.outline.em==='number') ? obj.outline.em : null
      } : null,
      centerScr: obj ? worldToScreen(obj.x, obj.y) : null,
      dist0: null
    };

    if (obj){
      migrateOutlineToEm(obj);
      if (drag.objStart.outlineEm==null && obj.outline) drag.objStart.outlineEm = obj.outline.em;
    }

    if (hit.mode === 'scale' && drag.centerScr){
      const d0 = Math.hypot(e.clientX - drag.centerScr.x, e.clientY - drag.centerScr.y);
      drag.dist0 = Math.max(8, d0, EPS);
    }

    window.addEventListener('mousemove', onDragMove, { passive:false });
    window.addEventListener('mouseup', onDragEnd, { passive:true });
  }

  function onDragMove(e){
    if (!drag) return;
    e.preventDefault();
    const dx = e.clientX - drag.start.x;
    const dy = e.clientY - drag.start.y;
    if (Math.hypot(dx,dy) > 2) drag.moved = true;

    const obj = objects.find(o=>o.id===activeObjId);
    if (!obj) return;

    switch(drag.mode){
      case 'move': {
        const dWorld = screenDeltaToWorld(dx, dy);
        obj.x = drag.objStart.x + dWorld.x;
        obj.y = drag.objStart.y + dWorld.y;
        clampActiveInsideViewport(obj);
        break;
      }
      case 'wrap-e': {
        // Ajusta largura por caractere — LIVRE (sem travar antes do conteúdo)
        const ang = (obj.rotationLocal||0) + rotation;
        const ux = Math.cos(ang), uy = Math.sin(ang);
        const proj = (dx*ux + dy*uy);
        const deltaWorld = proj / scale;
        const tentative = Math.max(20, Math.min(MAX_WRAP_W, drag.objStart.width + deltaWorld*2));
        obj.width = tentative;
        clampActiveInsideViewport(obj);
        break;
      }
      case 'rotate': {
        const c = drag.centerScr;
        const angleNow = Math.atan2(e.clientY - c.y, e.clientX - c.x);
        const target = angleNow - rotation;
        const prev = obj.rotationLocal || 0;
        obj.rotationLocal = prev + (target - prev) * ROT_SMOOTH;
        clampActiveInsideViewport(obj);
        break;
      }
      case 'scale': {
        // Escala PRO: size e width escalam pelo mesmo fator (centro fixo) → layout preservado, sem jitter
        const c = drag.centerScr;
        const distNow = Math.hypot(e.clientX - c.x, e.clientY - c.y);
        const factorRaw = distNow / Math.max(drag.dist0 || 1, EPS);
        const factor = Math.min(Math.max(factorRaw, 0.1), 50);

        const baseSize  = drag.objStart.size;
        const baseWidth = drag.objStart.width;

        const newSize  = Math.max(MIN_FONT_SIZE, Math.min(MAX_FONT_SIZE, baseSize * factor));
        const newWidth = Math.max(20, Math.min(MAX_WRAP_W, baseWidth * factor));

        obj.size  = newSize;
        obj.width = newWidth;

        // Contorno: mantém proporção via "em" (em é constante; largura real = em * size)
        if (obj.outline){
          obj.outline.em = (drag.objStart.outlineEm ?? obj.outline.em ?? 0.06);
        }

        clampActiveInsideViewport(obj);
        break;
      }
    }

    draw();
  }

  function onDragEnd(){
    window.removeEventListener('mousemove', onDragMove, { passive:false });
    window.removeEventListener('mouseup', onDragEnd, { passive:true });
    drag = null;
    draw();
  }

  // ---------- Touch de 1 dedo para editar OBJETO ----------
  function getTouchById(touchList, id){
    for (let i=0;i<touchList.length;i++){
      if (touchList[i].identifier === id) return touchList[i];
    }
    return null;
  }
  function beginDragFromPoint(clientX, clientY, hit){
    const fakeEvent = { clientX, clientY, preventDefault:()=>{} };
    beginDrag(fakeEvent, hit);
  }

  canvas.addEventListener('touchstart', (e)=>{
    if (e.touches.length === 1){
      const t = e.touches[0];

      if (pinchLastCenter) return;

      const hit = hitHandles(t.clientX, t.clientY);
      if (hit.mode !== 'none'){
        e.preventDefault();
        touchEditingActive = true;
        activeTouchId = t.identifier;
        beginDragFromPoint(t.clientX, t.clientY, hit);
        return;
      }

      const rect = canvas.getBoundingClientRect();
      const wpos = screenToWorld(t.clientX - rect.left, t.clientY - rect.top);
      const found = hitSelect(wpos.x, wpos.y);
      if (found){
        activeObjId = found.id;
        window.dispatchEvent(new CustomEvent('kanva:select', { detail:{ type:found.type, id:found.id } }));
        draw();
        e.preventDefault();
        touchEditingActive = true;
        activeTouchId = t.identifier;
        beginDragFromPoint(t.clientX, t.clientY, { mode:'move' });
      } else {
        if (activeObjId){
          activeObjId = null;
          window.dispatchEvent(new Event('kanva:deselect'));
          draw();
        }
      }
    }
  }, { passive:false });

  canvas.addEventListener('touchmove', (e)=>{
    if (!touchEditingActive) return;
    if (e.touches.length !== 1) return;

    const t = getTouchById(e.touches, activeTouchId);
    if (!t) return;

    e.preventDefault();
    onDragMove({ clientX: t.clientX, clientY: t.clientY, preventDefault: ()=>{} });
  }, { passive:false });

  canvas.addEventListener('touchend', (e)=>{
    const ended = e.changedTouches && getTouchById(e.changedTouches, activeTouchId);
    if (ended){
      touchEditingActive = false;
      activeTouchId = null;
      onDragEnd();
    }
  }, { passive:true });

  canvas.addEventListener('touchcancel', ()=>{
    if (touchEditingActive){
      touchEditingActive = false;
      activeTouchId = null;
      onDragEnd();
    }
  }, { passive:true });

  // ---------- Multitoque: SOMENTE 2 dedos (CANVAS) ----------
  canvas.addEventListener('touchstart', (e)=>{
    if (e.touches.length === 2){
      if (touchEditingActive){
        touchEditingActive = false;
        activeTouchId = null;
        onDragEnd();
      }
      const [t1, t2] = [e.touches[0], e.touches[1]];
      pinchLastDist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      pinchLastAngle = Math.atan2(t2.clientY - t1.clientY, t2.clientX - t1.clientX);
      pinchLastCenter = { x:(t1.clientX + t2.clientX)/2, y:(t1.clientY + t2.clientY)/2 };
    }
  }, { passive:true });

  canvas.addEventListener('touchmove', (e)=>{
    if (e.touches.length === 2){
      e.preventDefault();
      const [t1, t2] = [e.touches[0], e.touches[1]];
      const newDist   = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      const newAngle  = Math.atan2(t2.clientY - t1.clientY, t2.clientX - t1.clientX);
      const newCenter = { x:(t1.clientX + t2.clientX)/2, y:(t1.clientY + t2.clientY)/2 };

      // pan
      if (pinchLastCenter){
        translateX += newCenter.x - pinchLastCenter.x;
        translateY += newCenter.y - pinchLastCenter.y;
      }
      // zoom
      scale = Math.min(Math.max(scale * (newDist / Math.max(1, pinchLastDist)), 0.2), 8);
      // rotação global
      rotation += (newAngle - pinchLastAngle);

      pinchLastDist = newDist;
      pinchLastAngle = newAngle;
      pinchLastCenter = newCenter;
      draw();
    }
  }, { passive:false });

  canvas.addEventListener('touchend', (e)=>{
    if (e.touches.length < 2){
      pinchLastCenter = null;
    }
  }, { passive:true });

  // ---------- Duplo toque = alterna Fit / 100% ----------
  let lastTapTime = 0, tapTimer = null;
  canvas.addEventListener('touchstart', (e)=>{
    if (e.touches.length !== 1) return;
    const now = Date.now();
    if (now - lastTapTime < 280){
      clearTimeout(tapTimer);
      const { w:SW, h:SH } = screenSize();
      const pad = 24 + 84;
      const fit = Math.min((SW - 48)/project.width, (SH - pad)/project.height);
      if (Math.abs(scale - 1) < 0.01) scale = Math.max(0.1, fit);
      else scale = 1;
      translateX = 0; translateY = -20; rotation = 0;
      draw();
    } else {
      tapTimer = setTimeout(()=>{}, 180);
    }
    lastTapTime = now;
  }, { passive:true });

  // ---------- API pública (compat UI) ----------
  window.addTextObject = function(){
    const obj = {
      id: 't'+Math.random().toString(36).slice(2,8),
      type: 'Texto',
      text: 'Novo texto',
      x: 0, y: 0,
      color: '#ffffff',
      size: 48,
      width: 400,           // wrap inicial
      rotationLocal: 0,
      // Contorno em em (6% do tamanho da fonte)
      outline: { color: '#000000', em: 0.06 }
    };
    objects.unshift(obj);
    activeObjId = obj.id;
    if (window.addLayerFromObject) window.addLayerFromObject(obj);
    window.dispatchEvent(new CustomEvent('kanva:select', { detail:{ type:'Texto', id: obj.id } }));
    draw();
  };

  // Seleção externa (camadas/toolbar)
  window.addEventListener('kanva:select', (e)=>{
    const id = e.detail?.id;
    if (!id) return;
    const obj = objects.find(o=>o.id===id);
    if (obj){ activeObjId = id; draw(); }
  });
  window.addEventListener('kanva:deselect', ()=>{ activeObjId = null; draw(); });

  // ---------- Inicialização ----------
  setCanvasSize();
  (function initialFit(){
    const { w:SW, h:SH } = screenSize();
    const pad = 24 + 84;
    const fit = Math.min((SW - 48)/project.width, (SH - pad)/project.height);
    scale = Math.max(0.1, fit);
    translateX = 0;
    translateY = -20;
    rotation = 0;
  })();
  draw();

  console.log('Kanva v0.13.2-pro — canvas.js iniciado (escala estável, contorno em em, wrap livre).');
}
